package com.chicco.jarvis

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Lets JARVIS control other apps: tap text, scroll, Back/Home/Recents. */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun clickText(text: String): String {
        val root = rootInActiveWindow ?: return "no active window"
        var n: AccessibilityNodeInfo? = root.findAccessibilityNodeInfosByText(text).firstOrNull()
            ?: return "not found: " + text
        while (n != null && !n.isClickable) n = n.parent
        return if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) "clicked " + text
        else "click failed"
    }

    fun scroll(): String {
        val n = findScrollable(rootInActiveWindow) ?: return "nothing scrollable"
        return if (n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) "scrolled" else "scroll failed"
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val r = findScrollable(n.getChild(i))
            if (r != null) return r
        }
        return null
    }
}
