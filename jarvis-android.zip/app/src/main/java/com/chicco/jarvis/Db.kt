package com.chicco.jarvis

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/** Instruction log: every command you give, what the AI made of it, and the outcome. */
class Db(ctx: Context) : SQLiteOpenHelper(ctx, "jarvis.db", null, 1) {

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL(
            "CREATE TABLE log(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, " +
                "transcript TEXT, command TEXT, status TEXT, result TEXT)"
        )
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    fun insert(transcript: String, command: String, status: String, result: String) {
        val v = ContentValues().apply {
            put("ts", System.currentTimeMillis())
            put("transcript", transcript)
            put("command", command)
            put("status", status)
            put("result", result)
        }
        writableDatabase.insert("log", null, v)
    }

    /** Last n transcripts, oldest first, so the AI can handle "do that again". */
    fun recent(n: Int): String {
        val out = ArrayList<String>()
        readableDatabase.rawQuery(
            "SELECT transcript, result FROM log ORDER BY id DESC LIMIT ?", arrayOf(n.toString())
        ).use { c ->
            while (c.moveToNext()) out.add("- \"" + c.getString(0) + "\" -> " + c.getString(1))
        }
        out.reverse()
        return if (out.isEmpty()) "(none)" else out.joinToString("\n")
    }
}
