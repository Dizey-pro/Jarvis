package com.chicco.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/** Frontend HUD: live task feed, mic, typed commands. */
class MainActivity : Activity() {

    private lateinit var db: Db
    private lateinit var tts: TextToSpeech
    private lateinit var feed: TextView
    private lateinit var scroll: ScrollView
    private var recognizer: SpeechRecognizer? = null

    private val prefs by lazy { getSharedPreferences("jarvis", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = Db(this)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts.language = Locale.getDefault() }

        feed = findViewById(R.id.feed)
        scroll = findViewById(R.id.scroll)
        val key = findViewById<EditText>(R.id.key)
        val cmd = findViewById<EditText>(R.id.cmd)
        if (!prefs.getString("key", "").isNullOrBlank()) key.hint = "API key saved (enter new to replace)"

        findViewById<Button>(R.id.saveKey).setOnClickListener {
            val k = key.text.toString().trim()
            if (k.isNotEmpty()) {
                prefs.edit().putString("key", k).apply()
                key.setText("")
                log("API key saved")
            }
        }
        findViewById<Button>(R.id.a11y).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.send).setOnClickListener {
            val t = cmd.text.toString().trim()
            if (t.isNotEmpty()) {
                cmd.setText("")
                handle(t)
            }
        }
        findViewById<Button>(R.id.mic).setOnClickListener { listen() }
        log("Ready. Save your API key, enable Accessibility, then tap to talk.")
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("x No speech recognizer on this phone (install Google app)")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
            it.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            )
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) { log("... listening") }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(e: Int) { log("x mic error " + e) }
        override fun onPartialResults(p: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}
        override fun onResults(r: Bundle?) {
            r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { handle(it) }
        }
    }

    /** heard -> AI -> actions -> log -> speak */
    private fun handle(text: String) {
        log("> " + text)
        val key = prefs.getString("key", "") ?: ""
        if (key.isBlank()) {
            log("x Save your API key first")
            return
        }
        Thread {
            try {
                val reply = ClaudeClient.ask(key, text, db.recent(5))
                val acts = reply.optJSONArray("actions")
                val results = ArrayList<String>()
                if (acts != null) {
                    for (i in 0 until acts.length()) {
                        val a = acts.getJSONObject(i)
                        val r = Router.run(this@MainActivity, a)
                        results.add(r)
                        log("* " + a.optString("action") + " -> " + r)
                    }
                }
                db.insert(text, reply.toString(), "ok", results.joinToString("; "))
                val say = reply.optString("say")
                if (say.isNotBlank()) {
                    log("J: " + say)
                    runOnUiThread { tts.speak(say, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
                }
            } catch (e: Exception) {
                db.insert(text, "", "error", e.message ?: "")
                log("x " + e.message)
            }
        }.start()
    }

    private fun log(line: String) {
        runOnUiThread {
            feed.append(line + "\n")
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
