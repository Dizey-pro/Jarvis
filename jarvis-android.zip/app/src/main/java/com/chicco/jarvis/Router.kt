package com.chicco.jarvis

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import org.json.JSONObject

/** Backend executor: maps each JSON action to real device behaviour. */
object Router {

    fun run(ctx: Context, a: JSONObject): String = try {
        when (a.optString("action")) {
            "open_app" -> openApp(ctx, a.optString("target"))
            "open_url" -> {
                val u = a.optString("url")
                if (u.startsWith("http")) go(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u))) else "blocked url"
            }
            "web_search" -> go(
                ctx,
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query"))))
            )
            "dial" -> go(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.optString("number"))))
            "set_alarm" -> go(
                ctx,
                Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            )
            "set_timer" -> go(
                ctx,
                Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            )
            "ui_click", "ui_scroll", "ui_back", "ui_home", "ui_recents" -> ui(a)
            "none" -> "ok"
            else -> "unknown action"
        }
    } catch (e: Exception) {
        "failed: " + e.message
    }

    private fun go(ctx: Context, i: Intent): String {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "done"
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val hit = pm.queryIntentActivities(main, 0).firstOrNull {
            it.loadLabel(pm).toString().contains(name, ignoreCase = true)
        } ?: return "app not found: " + name
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "cannot launch"
        return go(ctx, launch)
    }

    private fun ui(a: JSONObject): String {
        val s = JarvisAccessibilityService.instance
            ?: return "enable Accessibility first"
        return when (a.optString("action")) {
            "ui_click" -> s.clickText(a.optString("text"))
            "ui_scroll" -> s.scroll()
            "ui_back" -> if (s.back()) "back" else "failed"
            "ui_home" -> if (s.home()) "home" else "failed"
            else -> if (s.recents()) "recents" else "failed"
        }
    }
}
