package com.chicco.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** AI layer: turns speech into a JSON command list. */
object ClaudeClient {

    private const val MODEL = "claude-sonnet-5-5"

    private const val SYSTEM = """You are JARVIS, a voice assistant that controls an Android phone.
Convert the user's speech into commands. Reply with ONLY one JSON object, no other text:
{"say": "short spoken reply", "actions": [ {"action": "...", ...} ]}

Allowed actions (use only these):
- {"action":"open_app","target":"app name"}
- {"action":"open_url","url":"https://..."}
- {"action":"web_search","query":"..."}
- {"action":"dial","number":"digits"}  (opens the dialer, never calls directly)
- {"action":"set_alarm","hour":0-23,"minute":0-59,"label":"..."}
- {"action":"set_timer","seconds":N,"label":"..."}
- {"action":"ui_click","text":"visible text of the button"}
- {"action":"ui_scroll"}
- {"action":"ui_back"}
- {"action":"ui_home"}
- {"action":"ui_recents"}
- {"action":"none"}  (for chat or questions: just answer in "say")

Keep "say" under 20 words. If the request is unclear or unsafe, use "none" and ask in "say"."""

    fun ask(key: String, transcript: String, history: String): JSONObject {
        val msg = "Recent commands:\n" + history + "\n\nNow: " + transcript
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 600)
            .put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", msg)))

        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.outputStream.use { it.write(body.toString().toByteArray()) }

        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw RuntimeException("API " + code + ": " + txt.take(200))

        val out = JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
        val s = out.indexOf('{')
        val e = out.lastIndexOf('}')
        if (s < 0 || e <= s) throw RuntimeException("AI returned no JSON")
        return JSONObject(out.substring(s, e + 1))
    }
}
